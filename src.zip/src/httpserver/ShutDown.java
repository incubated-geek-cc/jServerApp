package httpserver;

public class ShutDown extends Thread {
    @Override
    public void run() {
        JServerApp.shutDown();
    }
}