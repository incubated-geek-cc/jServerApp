package httpserver;

import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import httpserver.constant.ServerConstant;
import httpserver.handler.ServerResourceHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.File;

public class JServerApp implements Runnable {

    private static JServerApp server;
    private HttpServer httpServer;
    private ExecutorService executor;
    private static String serverHome;
    private static int port;
    
    public JServerApp() {
        
    }
   
    public static void main(String[] args) {
        serverHome = System.getProperty("user.dir");
        try {
            // Set folder where all static assets are placed in
            File webappFolder = new File(serverHome, ServerConstant.WEBAPP_DIR);
            if(!webappFolder.exists()) {
                webappFolder.mkdir();
            }
            // Set Port number
            try {
                Integer.parseInt(args[1]);
                port=Integer.parseInt(args[1]);
            } catch(Exception e) {
                e.printStackTrace();
                port = ServerConstant.DEFAULT_PORT;
            }
            server = new JServerApp();
            Thread thread = new Thread(server);
            thread.start();
            Runtime.getRuntime().addShutdownHook(new ShutDown());
            try {
                thread.join();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            executor = Executors.newFixedThreadPool(10);
            httpServer = HttpServer.create(new InetSocketAddress(ServerConstant.DEFAULT_HOST, port), 0);
            httpServer.createContext(ServerConstant.FORWARD_SINGLE_SLASH, 
                    new ServerResourceHandler(
                        serverHome + ServerConstant.FORWARD_SINGLE_SLASH + ServerConstant.WEBAPP_DIR, 
                        true, 
                        false
                    ));
            httpServer.setExecutor(executor);
            
            System.out.println("Starting server...");
            httpServer.start();
            System.out.println("Server started at: " + ServerConstant.DEFAULT_HOST + ":" + port);

            synchronized (this) {
                try {
                    this.wait();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    static void shutDown() {
        try {
            System.out.println("Shutting down server...");
            server.httpServer.stop(0);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        synchronized (server) {
            server.notifyAll();
        }
    }
}
